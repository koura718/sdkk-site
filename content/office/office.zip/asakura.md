+++
draft = false
date = "2017-01-22T09:52:34+09:00"
title = "朝倉営業所"
thumbnail = "images/office_asakura.jpg"

+++

        <div class="page-header2 text-left">
          <h2 class="headline rich_font h1_title">朝倉営業所</h2>
        </div>
        <div class="row">
          <div class="col-md-6"> <img src="images/office_asakura.jpg" class="img-responsive img_office" alt="朝倉営業所"> </div>
          <div class="col-md-6">
            <p>〒838-0065<br>
              福岡県朝倉市一木725番地1<br>
              TEL 0946-23-1231&nbsp;/&nbsp;FAX 0946-23-1221</p>
            <!--グーグルマップ▼ --> 
            <!-- body onload="initialize();" -->
            <div id="map_canvas" style="width:100%;height:235px;"></div>
            <!-- / グーグルマップ▲   --> 
          </div>
        </div>
        <div class="page-header2 text-left margin-t-20">
          <h2 class="headline rich_font h1_title">今年の目標</h2>
        </div>
        <div class="row">
          <div class="col-md-3"><img src="images/office_05.jpg" class="img-responsive img-thumbnail" alt="所長　古賀　貴博"/> </div>
          <div class="col-md-9">
            <h4 align="left" class="rich_font"><small>所長</small>　古賀　貴博</h4>
            <h3 class="rich_font h3_00">朝一の行動一つで、その日の成果が変わる！<br>
              常にお客様の立場になり物事を考え行動する！ </h3>
          </div>
        </div>
