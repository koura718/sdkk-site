+++
draft = false
date = "2017-01-25T09:52:34+09:00"
title = "南営業所"
thumbnail = "images/office_minami.jpg"

+++

        <div class="page-header2 text-left">
          <h2 class="headline rich_font h1_title">南営業所</h2>
        </div>
        <div class="row">
          <div class="col-md-6"> <img src="images/office_minami.jpg" class="img-responsive img_office" alt="南営業所"> </div>
          <div class="col-md-6">
            <p>〒811-1201<br>
              福岡県那珂川市片縄1丁目70<br>
              TEL 092-953-1215&nbsp;/&nbsp;FAX 092-953-1570</p>
            <!--グーグルマップ▼ --> 
            <!-- body onload="initialize();" -->
            <div id="map_canvas" style="width:100%;height:235px;"></div>
            <!-- / グーグルマップ▲   --> 
          </div>
        </div>
        <div class="page-header2 text-left margin-t-20">
          <h2 class="headline rich_font h1_title">今年の目標</h2>
        </div>
        <div class="row">
          <div class="col-md-3"><img src="images/minami__kawaguchi_f.jpg" class="img-responsive img-thumbnail" alt="所長　川口 洋平"/> </div>
          <div class="col-md-9">
            <h4 align="left" class="rich_font"><small>所長</small>　川口 洋平</h4>
            <h3 class="rich_font h3_00">笑顔の絶えない職場作り　目標に向かって一致団結！！</h3>
          </div>
        </div>
