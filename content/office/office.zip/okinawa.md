+++
draft = false
date = "2017-01-21T09:52:34+09:00"
title = "沖縄営業所"
thumbnail = "images/office_okinawa.jpg"

+++

        <div class="page-header2 text-left">
          <h2 class="headline rich_font h1_title">沖縄営業所</h2>
        </div>
        <div class="row">
          <div class="col-md-6"> <img src="images/office_okinawa.jpg" class="img-responsive img_office" alt="三共電気本社"> </div>
          <div class="col-md-6">
            <p>〒904-2143<br>
              沖縄県沖縄市知花５丁目35-27<br>
              TEL 098-921-1839&nbsp;/&nbsp;FAX 098-921-1880</p>
            <!--グーグルマップ▼ --> 
            <!-- body onload="initialize();" -->
            <div id="map_canvas" style="width:100%;height:235px;"></div>
            <!-- / グーグルマップ▲   --> 
          </div>
        </div>
        <div class="page-header2 text-left margin-t-20">
          <h2 class="headline rich_font h1_title">今年の目標</h2>
        </div>
        <div class="row">
          <div class="col-md-3"><img src="images/office_04.jpg" class="img-responsive img-thumbnail" alt="所長　蒲原　圭太"/> </div>
          <div class="col-md-9">
            <h4 align="left" class="rich_font"><small>所長</small>　蒲原 圭太</h4>
            <h3 class="rich_font h3_00">新規開拓・地域密着・無事故</h3>
          </div>
        </div>
        <div id="map"></div>
		