+++
draft = false
date = "2017-01-27T09:52:34+09:00"
title = "本社"
thumbnail = "images/office_honsya.jpg"
+++

        <div class="page-header2 text-left">
          <h2 class="headline rich_font h1_title">本  社</h2>
        </div>
        <div class="row">
          <div class="col-sm-6"> <img src="images/office_honsya.jpg" class="img-responsive img_office" alt="三共電気本社"> </div>
          <div class="col-sm-6">
            <p>〒819-0022<br>
              福岡市西区福重１丁目14-25<br>
              TEL 092-883-8588&nbsp;/&nbsp;FAX 092-883-8810</p>
            <!--グーグルマップ▼ --> 
            <!-- body onload="initialize();" -->
            <div id="map_canvas" style="width:100%;height:235px;"></div>
            <!-- / グーグルマップ▲   --> 
          </div>
        </div>
        <!--本社▲-->
        <div class="page-header2 text-left margin-t-20">
          <h2 class="headline rich_font h1_title">今年の目標</h2>
        </div>
        <div class="row margin-t-20">
          <div class="col-sm-3"><img src="images/office_08.jpg" class="img-responsive img-thumbnail" alt="常務　中村　雄二郎"/> </div>
          <div class="col-sm-9">
            <h4 align="left" class="rich_font"><small>常務</small>　中村 雄二郎</h4>
            <h3 class="rich_font h3_00">勇往邁進<br>
              自分を信じ突き進め！！ </h3>
          </div>
        </div>
        <div class="row margin-t-20">
          <div class="col-sm-3"><img src="images/office_06.jpg" class="img-responsive img-thumbnail" alt="常務　時松　博幸"/> </div>
          <div class="col-sm-9">
            <h4 align="left" class="rich_font"><small>常務</small>　時松 博幸</h4>
            <h3 class="rich_font h3_00">幸せになる勇気を持っているか？<br>
              変化、変革を恐れるな！<br>
              みんなで目指す売上１００億！！</h3>
          </div>
        </div>
        <div class="row margin-t-20">
          <div class="col-sm-3"><img src="images/office_10.jpg" class="img-responsive img-thumbnail" alt="取締役部長　副島 健太"/> </div>
          <div class="col-sm-9">
            <h4 align="left" class="rich_font"><small>取締役部長</small>　副島 健太</h4>
            <h3 class="rich_font h3_00">個々のスキルアップと営業所内での協調
              <ol>
                <li>営業・業務・女性　個人のスキルアップ</li>
                <li>各部署が連携して仕事ができるように取り組む</li>
                <li>情報の共有・報連相の徹底</li>
              </ol>
            </h3>
          </div>
        </div>
        <div class="row margin-t-20">
          <div class="col-sm-3"><img src="images/office_01.jpg" class="img-responsive img-thumbnail" alt="次長　中村　裕治"/> </div>
          <div class="col-sm-9">
            <h4 align="left" class="rich_font"><small>本社 営業1課 次長</small>　中村 裕治 </h4>
            <h3 class="rich_font h3_00">チ＝力を合わせ<br>
              ム＝無理難題も<br>
              ワ＝和の精神で<br>
             　（チームの調和、心を合わせる）<br>
              ク＝苦難を乗り越え<br><br>
              　チームワークで成果を果たす！</h3>
          </div>
        </div>
        <div class="row margin-t-20">
          <div class="col-sm-3"><img src="images/office_02.jpg" class="img-responsive img-thumbnail" alt="課長　園田　和人"/> </div>
          <div class="col-sm-9">
            <h4 align="left" class="rich_font"><small>本社 営業2課 課長</small>　園田 和人 </h4>
            <h3 class="rich_font h3_00">報告・連絡・相談</h3>
          </div>
        </div>
