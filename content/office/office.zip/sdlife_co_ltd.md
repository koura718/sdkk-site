+++
draft = false
date = "2017-01-26T09:52:34+09:00"
title = "株式会社 エスディライフ"
thumbnail = "images/sd_life_office.jpg"

+++

        <div class="page-header2 text-left">
          <h2 class="headline rich_font h1_title">株式会社エスディライフ</h2>
        </div>
        <div class="row">
          <div class="col-md-6"> <img src="images/sd_life_office.jpg" class="img-responsive img_office" alt="三共電気本社"> </div>
          <div class="col-md-6">
            <p>〒819-0022<br>
              福岡市西区福重１丁目14-25<br>
              TEL 092-894-1521&nbsp;/&nbsp;FAX 092-894-1522</p>
            <!--グーグルマップ▼ --> 
            <!-- body onload="initialize();" -->
            <div id="map_canvas" style="width:100%;height:235px;"></div>
            <!-- / グーグルマップ▲   --> 
          </div>
        </div>
        <!--本社▲-->
        <div class="page-header2 text-left margin-t-20">
          <h2 class="headline rich_font h1_title">エスディライフ今年の目標</h2>
        </div>
        <div class="row">
          <div class="col-md-3"><img src="images/office_03.jpg" class="img-responsive img-thumbnail" alt="社長　馬場　博"/> </div>
          <div class="col-md-9">
            <h4 align="left" class="rich_font"><small>社長</small>　馬場　博</h4>
            <h3 class="rich_font h3_00">愛のある仕事を！！</h3>
          </div>
        </div>
