+++
draft = false
date = "2017-01-23T09:52:34+09:00"
title = "筑豊営業所"
thumbnail = "images/office_tikuhou.jpg"

+++

        <div class="page-header2 text-left">
          <h2 class="headline rich_font h1_title">筑豊営業所</h2>
        </div>
        <div class="row">
          <div class="col-md-6"> <img src="images/office_tikuhou.jpg" class="img-responsive img_office" alt="筑豊営業所"> </div>
          <div class="col-md-6">
            <p>〒820-0071<br>
              福岡県飯塚市忠隈359-1<br>
              TEL 0948-25-8133&nbsp;/&nbsp;FAX 0948-25-8134</p>
            <!--グーグルマップ▼ --> 
            <!-- body onload="initialize();" -->
            <div id="map_canvas" style="width:100%;height:235px;"></div>
            <!-- / グーグルマップ▲   --> 
          </div>
        </div>
        <div class="page-header2 text-left margin-t-20">
          <h2 class="headline rich_font h1_title">今年の目標</h2>
        </div>
        <div class="row">
          <div class="col-md-3"><img src="images/chikuhou__itano_f.jpg" class="img-responsive img-thumbnail" alt="所長　坂野 政彦"/> </div>
          <div class="col-md-9">
            <h4 align="left" class="rich_font"><small>所長</small>　坂野 政彦</h4>
            <h3 class="rich_font h3_00">全員で一歩ずつ！！</h3>
          </div>
        </div>
