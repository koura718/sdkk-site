+++
draft = false
date = "2017-01-24T09:52:34+09:00"
title = "東営業所"
thumbnail = "images/office_higasi.jpg"

+++

        <div class="page-header2 text-left">
          <h2 class="headline rich_font h1_title">東営業所</h2>
        </div>
        <div class="row">
          <div class="col-md-6"> <img src="images/office_higasi.jpg" class="img-responsive img_office" alt="東営業所"> </div>
          <div class="col-md-6">
            <p>〒811-2305<br>
              粕屋郡粕屋町柚須十日田93-3<br>
              TEL 092-623-7333&nbsp;/&nbsp;FAX 092-623-7335</p>
            <!--グーグルマップ▼ --> 
            <!-- body onload="initialize();" -->
            <div id="map_canvas" style="width:100%;height:235px;"></div>
            <!-- / グーグルマップ▲   --> 
          </div>
        </div>
        <div class="page-header2 text-left margin-t-20">
          <h2 class="headline rich_font h1_title">今年の目標</h2>
        </div>
        <div class="row">
          <div class="col-md-3"><img src="images/office_09.jpg" class="img-responsive img-thumbnail" alt="所長　山口　一郎"/> </div>
          <div class="col-md-9">
            <h4 align="left" class="rich_font"><small>所長</small>　山口　一郎</h4>
            <h3 class="rich_font h3_00">一致共同・自己責任</h3>
          </div>
        </div>
